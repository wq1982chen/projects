
package com.neo;



import org.junit.Test;

public class SwaggerApplicationTests {

	@Test
	public void test() {
	}

}
